let str = "";

let buttons = document.querySelectorAll("input[type='button'");

var i = document.querySelector("input[type='text'");

buttons.forEach((element) => {
  element.addEventListener("click", () => {

    if (element.value == "=") {
      str = eval(str);
      i.setAttribute("value", str);

    } 
    
    else if (element.value == "C") {
      str = "";
      i.setAttribute("value", str);
    } 
    
    else {
      str += element.value;
      i.setAttribute("value", str);
    }
  });
});